package com.vivin.appprofile;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class EditProfileActivity extends Activity {

    EditText nameInput, usernameInput, bioInput, contactInput;
    Spinner countrySpinner;

    final int primary = Color.rgb(86, 96, 139);

    int dp(float value) {
        return (int) (value * getResources()
                .getDisplayMetrics().density + 0.5f);
    }

    LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(
                width < 0 ? width : dp(width),
                height < 0 ? height : dp(height));
    }

    TextView label(String value) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextSize(14);
        text.setTextColor(Color.rgb(55, 55, 55));
        text.setTypeface(null, Typeface.BOLD);
        return text;
    }

    EditText field(String hint) {
        EditText edit = new EditText(this);
        edit.setHint(hint);
        edit.setTextSize(14);
        edit.setPadding(dp(12), dp(5), dp(12), dp(5));
        edit.setBackgroundTintList(
                ColorStateList.valueOf(Color.LTGRAY));
        return edit;
    }

    void addField(LinearLayout root, String title,
                  View input, int height) {

        LinearLayout.LayoutParams labelParams = lp(-1, -2);
        labelParams.topMargin = dp(13);
        root.addView(label(title), labelParams);

        LinearLayout.LayoutParams inputParams = lp(-1, height);
        inputParams.topMargin = dp(3);
        root.addView(input, inputParams);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent old = getIntent();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.WHITE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(16), dp(24), dp(24));
        scroll.addView(root);

        // Header
        TextView header = label("‹     Edit Profile");
        header.setTextSize(21);
        root.addView(header, lp(-1, 48));
        header.setOnClickListener(v -> finish());

        // Profile photo
        ImageView photo = new ImageView(this);
        photo.setImageResource(R.drawable.profile_photoo);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);

        LinearLayout.LayoutParams photoParams = lp(100, 100);
        photoParams.gravity = Gravity.CENTER_HORIZONTAL;
        photoParams.topMargin = dp(15);
        photoParams.bottomMargin = dp(10);
        root.addView(photo, photoParams);

        // Name
        nameInput = field("Enter your name");
        nameInput.setText(old.getStringExtra("name"));
        addField(root, "Name", nameInput, 50);

        // Username
        usernameInput = field("Enter your username");
        usernameInput.setText(old.getStringExtra("username"));
        addField(root, "Username", usernameInput, 50);

        // Bio
        bioInput = field("Write your bio");
        bioInput.setSingleLine(false);
        bioInput.setMinLines(3);
        bioInput.setGravity(Gravity.TOP);
        bioInput.setText(old.getStringExtra("bio"));
        addField(root, "Bio", bioInput, 85);

        // Contact
        contactInput = field("Enter your email");
        contactInput.setInputType(
                android.text.InputType.TYPE_CLASS_TEXT |
                        android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        contactInput.setText(old.getStringExtra("contact"));
        addField(root, "Contact", contactInput, 50);

        // Country / Region
        countrySpinner = new Spinner(this);

        String[] countries = {
                "Indonesia",
                "Malaysia",
                "Singapore",
                "Thailand",
                "United States",
                "United Kingdom"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                countries);

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        countrySpinner.setAdapter(adapter);

        String country = old.getStringExtra("country");

        if (country != null) {
            int position = adapter.getPosition(country);
            if (position >= 0) {
                countrySpinner.setSelection(position);
            }
        }

        addField(root, "Country/Region", countrySpinner, 50);

        // Save Changes
        Button save = new Button(this);
        save.setText("Save Changes");
        save.setAllCaps(false);
        save.setTextColor(Color.WHITE);
        save.setBackgroundTintList(
                ColorStateList.valueOf(primary));

        LinearLayout.LayoutParams saveParams = lp(-1, 50);
        saveParams.topMargin = dp(24);
        root.addView(save, saveParams);

        save.setOnClickListener(v -> {
            String name = nameInput.getText()
                    .toString().trim();

            String username = usernameInput.getText()
                    .toString().trim();

            if (name.isEmpty() || username.isEmpty()) {
                Toast.makeText(
                        this,
                        "Name dan Username wajib diisi",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            Intent result = new Intent();
            result.putExtra("name", name);
            result.putExtra("username", username);
            result.putExtra("bio",
                    bioInput.getText().toString().trim());
            result.putExtra("contact",
                    contactInput.getText().toString().trim());
            result.putExtra("country",
                    countrySpinner.getSelectedItem().toString());

            setResult(RESULT_OK, result);
            finish();
        });

        setContentView(scroll);
    }
}
